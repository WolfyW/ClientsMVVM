﻿using System.Windows.Controls;

namespace ClientsMVVM.View
{
    /// <summary>
    /// Логика взаимодействия для ClientDetailViewModel.xaml
    /// </summary>
    public partial class ClientDetailView : UserControl
    {
        public ClientDetailView()
        {
            InitializeComponent();
        }
    }
}
